import React from "react";

const ContactDesc = () => {
    return(
        <div className="container contact-desc">
            <p>For more detailed information and inquiries, please contact our engineering team.</p>
        </div>
    )
}

export default ContactDesc;